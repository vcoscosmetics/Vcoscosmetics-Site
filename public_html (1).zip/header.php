	<header class="header-area" id="sticky-header">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-2">
					<div class="logo">
						<a href="index.html"><img src="assets/images/logo.png" alt=""></a>
					</div>
				</div>
				<div class="col-lg-10">
					<div class="header-menu">
						<ul>
							<li><a href="#">Home</a>
							</li>
							<li><a href="about.html">About Us</a></li>
							<li><a href="#">Products </a>
							</li>
							<li><a href="service.html">Service </a>
							</li>
							<li><a href="#">FAQ's </a>
							</li>
							<li><a href="contact.html">Contacts Us</a></li>
						</ul>
						<div class="header-right">
							<div class="header-search">
								<a class="search-box-btn search-box-outer" href="#"><i class="bi bi-search"></i></a>
							</div>
							<div class="Lifesafe-btn">
								<a href="#">Call Now</a>
							</div>
							<div class="header-sidebar">
								<a class="navSidebar-button" href="#"><i class="bi bi-grid-3x3-gap-fill"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>