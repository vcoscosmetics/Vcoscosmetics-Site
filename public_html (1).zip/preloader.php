	<div class="loader-wrapper">
		<div class="loader-wrap">
			<div class="preloader">
				<div id="shifa-preloader" class="shifa-preloader">
					<div class="layer layer-one"><span class="overlay"></span></div>
					<div class="animation-preloader">
						<div class="spinner"></div>
						<div class="txt-loading">
							<span data-text-preloader="V" class="letters-loading">
								V
							</span>
							<span data-text-preloader="C" class="letters-loading">
								C
							</span>
							<span data-text-preloader="O" class="letters-loading">
								O
							</span>
							<span data-text-preloader="S" class="letters-loading">
								S
							</span>
							<span data-text-preloader="M" class="letters-loading">
								M
							</span>
							<span data-text-preloader="E" class="letters-loading">
								E
							</span>
							<span data-text-preloader="T" class="letters-loading">
								T
							</span>
							<span data-text-preloader="I" class="letters-loading">
								I
							</span>
							<span data-text-preloader="C" class="letters-loading">
								C
							</span>
							<span data-text-preloader="S" class="letters-loading">
								S
							</span>
						</div>
					</div>  
				</div>
			</div>
		</div>
		<div class="loader"></div>
		<div class="loder-section left-section"></div>
		<div class="loder-section right-section"></div>
	</div>